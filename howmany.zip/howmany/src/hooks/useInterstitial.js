/**
 * useInterstitial.js
 * Tracks how many times the user has asked a question.
 * Returns a function that fires a callback — immediately, or after
 * showing the interstitial ad on every 3rd call.
 */
import { useState, useRef, useCallback } from 'react'

const EVERY = 3  // show interstitial every N resets

export function useInterstitial() {
  const countRef = useRef(0)
  const [visible, setVisible] = useState(false)
  const [countdown, setCountdown] = useState(5)
  const [canSkip, setCanSkip] = useState(false)
  const timerRef = useRef(null)
  const onDoneRef = useRef(null)

  const maybeShow = useCallback((onDone) => {
    countRef.current += 1
    const shouldShow = countRef.current % EVERY === 0

    if (!shouldShow) {
      onDone()
      return
    }

    // Show interstitial
    onDoneRef.current = onDone
    setVisible(true)
    setCountdown(5)
    setCanSkip(false)

    let sec = 5
    clearInterval(timerRef.current)
    timerRef.current = setInterval(() => {
      sec -= 1
      setCountdown(sec)
      if (sec <= 0) {
        clearInterval(timerRef.current)
        setCanSkip(true)
      }
    }, 1000)
  }, [])

  const skip = useCallback(() => {
    if (!canSkip) return
    clearInterval(timerRef.current)
    setVisible(false)
    if (onDoneRef.current) onDoneRef.current()
  }, [canSkip])

  // How many questions until next interstitial (for the counter label)
  const untilNext = EVERY - (countRef.current % EVERY)
  const showingCounter = untilNext < EVERY

  return { visible, countdown, canSkip, skip, maybeShow, showingCounter, untilNext }
}
