import { forwardRef, useState, useRef, useEffect } from 'react'

const QuestionInput = forwardRef(function QuestionInput({ onAsk, disabled }, ref) {
  const [value, setValue] = useState('')
  const [shaking, setShaking] = useState(false)
  const [listening, setListening] = useState(false)
  const recognitionRef = useRef(null)
  const micSupported = useRef(false)

  useEffect(() => {
    if ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window) {
      const SR = window.SpeechRecognition || window.webkitSpeechRecognition
      const rec = new SR()
      rec.lang = 'en-US'
      rec.interimResults = false
      rec.onresult = (e) => {
        const t = e.results[0][0].transcript
        setListening(false)
        setValue(t)
        onAsk(t)
      }
      rec.onend  = () => setListening(false)
      rec.onerror= () => setListening(false)
      recognitionRef.current = rec
      micSupported.current = true
    }
  }, [onAsk])

  const shake = () => {
    setShaking(true)
    setTimeout(() => setShaking(false), 500)
  }

  const handleSubmit = () => {
    const v = value.trim()
    if (v.length < 3) { shake(); return }
    onAsk(v)
  }

  const handleKey = (e) => {
    if (e.key === 'Enter') handleSubmit()
  }

  const toggleMic = () => {
    if (!micSupported.current) return
    if (listening) {
      recognitionRef.current.stop()
      setListening(false)
    } else {
      setListening(true)
      recognitionRef.current.start()
    }
  }

  return (
    <div style={{ position: 'relative', marginBottom: 10 }}>
      <input
        ref={ref}
        value={value}
        onChange={e => setValue(e.target.value)}
        onKeyDown={handleKey}
        placeholder="How many sheets of paper are in a tree?"
        maxLength={300}
        disabled={disabled}
        className={shaking ? 'shake' : ''}
        style={{
          width: '100%',
          background: 'var(--card2)',
          border: '1.5px solid rgba(245,200,66,0.2)',
          borderRadius: 'var(--radius)',
          padding: '16px 58px 16px 20px',
          fontFamily: 'var(--font-body)',
          fontSize: 15,
          color: 'var(--white)',
          outline: 'none',
          caretColor: 'var(--gold)',
          opacity: disabled ? 0.6 : 1,
        }}
      />
      <button
        onClick={toggleMic}
        title={micSupported.current ? 'Tap to speak' : 'Voice requires Chrome or Edge'}
        style={{
          position: 'absolute', right: 10, top: '50%', transform: 'translateY(-50%)',
          width: 38, height: 38, borderRadius: '50%', border: 'none',
          background: listening ? 'var(--coral)' : 'var(--gold)',
          color: 'var(--sky)', cursor: micSupported.current ? 'pointer' : 'not-allowed',
          display: 'flex', alignItems: 'center', justifyContent: 'center',
          fontSize: 16, opacity: micSupported.current ? 1 : 0.3,
          animation: listening ? 'pulse 1s ease-in-out infinite' : 'none',
        }}
      >
        🎤
      </button>
    </div>
  )
})

export default QuestionInput
