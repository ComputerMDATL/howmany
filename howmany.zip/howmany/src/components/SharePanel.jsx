import { useState, useRef, useEffect } from 'react'
import { drawShareCard, SHARE_STYLES } from '../lib/shareCard'

const SWATCH_STYLES = [
  'linear-gradient(135deg,#0B1A2E,#1E2D47)',
  'linear-gradient(135deg,#120228,#2a0d52)',
  'linear-gradient(135deg,#062015,#0d3d25)',
  'linear-gradient(135deg,#150700,#3d1800)',
  'linear-gradient(135deg,#F8F4EC,#E8E4D8)',
]

export default function SharePanel({ question, answer, onClose, onToast }) {
  const [styleIdx, setStyleIdx] = useState(0)
  const canvasRef = useRef(null)

  useEffect(() => {
    document.fonts.ready.then(() => {
      if (canvasRef.current) {
        drawShareCard(canvasRef.current, { question, answer, styleIndex: styleIdx })
      }
    })
  }, [question, answer, styleIdx])

  const handleDownload = () => {
    const slug = (question || 'answer').slice(0, 40).replace(/[^a-z0-9]/gi, '-').toLowerCase()
    const a = document.createElement('a')
    a.download = `howmany-${slug}.png`
    a.href = canvasRef.current.toDataURL('image/png')
    a.click()
  }

  const handleCopyLink = () => {
    const url = `https://howmany.app/?q=${encodeURIComponent(question.slice(0, 200))}`
    navigator.clipboard.writeText(url).catch(() => {})
    onToast('Link copied! 🔗')
  }

  return (
    <div className="slide-up" style={{
      background: 'var(--card)', border: '1px solid rgba(245,200,66,0.15)',
      borderRadius: 22, overflow: 'hidden', marginTop: 12,
    }}>
      <div style={{ padding: '16px 22px 12px', borderBottom: '1px solid rgba(255,255,255,0.06)', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ fontSize: 13, fontWeight: 600 }}>Share card</div>
        <button onClick={onClose} style={{ background: 'none', border: 'none', color: 'var(--muted)', fontSize: 16, cursor: 'pointer', padding: '2px 6px', borderRadius: 6 }}>✕</button>
      </div>
      <div style={{ padding: '14px 22px 18px' }}>
        <div style={{ fontSize: 10, color: 'var(--muted)', fontWeight: 600, letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: 8 }}>
          Preview — 1200 × 630 (OG card size)
        </div>
        <canvas ref={canvasRef} width={1200} height={630} style={{ width: '100%', height: 'auto', display: 'block', borderRadius: 10, border: '1px solid rgba(255,255,255,0.06)' }} />

        {/* Style swatches */}
        <div style={{ display: 'flex', gap: 7, margin: '10px 0 14px', alignItems: 'center' }}>
          {SWATCH_STYLES.map((bg, i) => (
            <button key={i} onClick={() => setStyleIdx(i)} style={{
              width: 26, height: 26, borderRadius: '50%', cursor: 'pointer',
              border: `2px solid ${styleIdx === i ? 'white' : 'transparent'}`,
              background: bg,
              transform: styleIdx === i ? 'scale(1.18)' : 'scale(1)',
              transition: 'all 0.18s', flexShrink: 0,
            }} />
          ))}
          <span style={{ fontSize: 11, color: 'var(--muted)', marginLeft: 4 }}>Pick a style</span>
        </div>

        {/* Buttons */}
        <div style={{ display: 'flex', gap: 9 }}>
          <button onClick={handleDownload} style={{
            flex: 1, background: 'var(--gold)', color: 'var(--sky)', border: 'none',
            borderRadius: 40, padding: '11px 18px', fontFamily: 'var(--font-body)',
            fontSize: 13, fontWeight: 600, cursor: 'pointer', display: 'flex',
            alignItems: 'center', justifyContent: 'center', gap: 6,
          }}>
            ⬇ Download PNG
          </button>
          <button onClick={handleCopyLink} style={{
            background: 'transparent', border: '1px solid rgba(255,255,255,0.15)',
            color: 'var(--muted)', borderRadius: 40, padding: '11px 16px',
            fontFamily: 'var(--font-body)', fontSize: 12, cursor: 'pointer', whiteSpace: 'nowrap',
          }}>
            🔗 Copy link
          </button>
        </div>
      </div>
    </div>
  )
}
