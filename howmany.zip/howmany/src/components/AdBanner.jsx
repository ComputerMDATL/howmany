/**
 * AdBanner.jsx
 * AD SLOT 1 — banner below answer card.
 *
 * IN PRODUCTION: Replace the mock content inside <div className="ad-inner">
 * with a real AdSense <ins> tag:
 *
 *   <ins className="adsbygoogle"
 *     style={{ display: 'block' }}
 *     data-ad-client="ca-pub-XXXXXXXXXXXXXXXX"
 *     data-ad-slot="XXXXXXXXXX"
 *     data-ad-format="auto"
 *     data-full-width-responsive="true"
 *     data-tag-for-child-directed-treatment="1"  ← REQUIRED for kid safety + COPPA
 *   />
 *   Then call (window.adsbygoogle = window.adsbygoogle || []).push({})
 *   inside a useEffect.
 */
import { useMemo } from 'react'

const MOCK_ADS = [
  { icon: '🔭', title: 'Sky Map — Explore the Night Sky',      sub: 'Point your phone up. See every star, planet & constellation.', cta: 'Free Download' },
  { icon: '🧪', title: 'MEL Science Kits',                     sub: 'Monthly science experiments delivered to your door.',          cta: 'Learn More'    },
  { icon: '📚', title: 'Khan Academy Kids',                     sub: 'Free learning for ages 2–8. Math, reading, and more.',        cta: 'Try Free'      },
  { icon: '🌍', title: 'National Geographic Kids',              sub: 'Wild facts, amazing animals, science & geography.',           cta: 'Explore'       },
]

export function AdBanner() {
  const ad = useMemo(() => MOCK_ADS[Math.floor(Math.random() * MOCK_ADS.length)], [])

  return (
    <div className="fade-in" style={{ marginTop: 12 }}>
      {/* REPLACE THIS DIV with the AdSense <ins> tag in production */}
      <div style={{
        background: 'var(--card2)', border: '1px solid rgba(255,255,255,0.08)',
        borderRadius: 14, padding: '10px 14px', display: 'flex', alignItems: 'center',
        gap: 12, minHeight: 72,
      }}>
        <span style={{ fontSize: 9, color: 'var(--muted)', fontWeight: 600, letterSpacing: '0.07em', textTransform: 'uppercase', background: 'rgba(255,255,255,0.06)', padding: '2px 6px', borderRadius: 4, flexShrink: 0 }}>Ad</span>
        <div style={{ width: 44, height: 44, borderRadius: 10, background: 'rgba(245,200,66,0.1)', border: '1px solid rgba(245,200,66,0.15)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 20, flexShrink: 0 }}>
          {ad.icon}
        </div>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--white)', marginBottom: 2 }}>{ad.title}</div>
          <div style={{ fontSize: 11, color: 'var(--muted)', lineHeight: 1.4 }}>{ad.sub}</div>
        </div>
        <button style={{ background: 'var(--gold)', color: 'var(--sky)', border: 'none', borderRadius: 8, padding: '7px 14px', fontFamily: 'var(--font-body)', fontSize: 12, fontWeight: 600, cursor: 'pointer', whiteSpace: 'nowrap', flexShrink: 0 }}>
          {ad.cta}
        </button>
      </div>
    </div>
  )
}

export default AdBanner

/**
 * Interstitial.jsx
 * AD SLOT 2 — full-screen interstitial every 3rd "Ask another".
 *
 * IN PRODUCTION: Replace the mock ad content with AdMob interstitial SDK
 * calls (mobile) or AdSense interstitial (web). The countdown + skip
 * logic stays identical.
 */
const INT_ADS = [
  { icon: '🚀', title: 'Did you know NASA has a free app?',   sub: 'Explore the solar system, track the ISS, and watch rocket launches live.',  cta: 'Get NASA App — Free', color: '#00C9A7' },
  { icon: '🔬', title: 'Curiosity Stream',                    sub: 'Thousands of documentaries about science, nature, history, and space.',      cta: 'Try 30 Days Free',   color: '#6B8CFF' },
  { icon: '🦁', title: 'Smithsonian Channel',                 sub: 'Real science. Real stories. Wild planet, amazing animals.',                  cta: 'Watch Now',          color: '#F5C842' },
]

export function Interstitial({ visible, countdown, canSkip, skip }) {
  if (!visible) return null
  const ad = INT_ADS[Math.floor(Date.now() / 10000) % INT_ADS.length]

  return (
    <div style={{
      position: 'fixed', inset: 0, zIndex: 100,
      background: 'rgba(0,0,0,0.8)',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      padding: 20,
    }}>
      <div className="slide-up" style={{
        background: 'var(--card)', border: '1px solid rgba(255,255,255,0.1)',
        borderRadius: 20, width: '100%', maxWidth: 400, overflow: 'hidden',
      }}>
        {/* Progress bar */}
        <div style={{ height: 3, background: 'rgba(255,255,255,0.06)' }}>
          <div style={{ height: '100%', background: 'var(--gold)', width: `${(countdown / 5) * 100}%`, transition: 'width 0.1s linear' }} />
        </div>
        {/* Header */}
        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '14px 16px 12px', borderBottom: '1px solid rgba(255,255,255,0.07)' }}>
          <span style={{ fontSize: 10, color: 'var(--muted)', fontWeight: 600, letterSpacing: '0.06em', textTransform: 'uppercase' }}>Advertisement</span>
          <span style={{ fontSize: 12, color: canSkip ? 'var(--teal)' : 'var(--muted)', fontWeight: 500 }}>
            {canSkip ? 'Ready!' : `Skip in ${countdown}s`}
          </span>
          <button onClick={skip} disabled={!canSkip} style={{
            background: 'none', border: 'none', color: canSkip ? 'var(--white)' : 'var(--muted)',
            fontSize: 12, fontFamily: 'var(--font-body)', cursor: canSkip ? 'pointer' : 'not-allowed',
            padding: '4px 8px', borderRadius: 6, opacity: canSkip ? 1 : 0.4,
          }}>
            Skip ✕
          </button>
        </div>
        {/* Ad content */}
        <div style={{ padding: '24px 20px', textAlign: 'center' }}>
          <div style={{ width: 56, height: 56, borderRadius: 14, background: `${ad.color}22`, border: `1px solid ${ad.color}44`, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 28, margin: '0 auto 14px' }}>
            {ad.icon}
          </div>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: 22, fontWeight: 700, color: 'var(--white)', marginBottom: 7 }}>
            {ad.title}
          </div>
          <div style={{ fontSize: 13, color: 'var(--muted)', lineHeight: 1.55, marginBottom: 20 }}>
            {ad.sub}
          </div>
          <button onClick={skip} style={{ width: '100%', background: ad.color, color: 'var(--sky)', border: 'none', borderRadius: 40, padding: 13, fontFamily: 'var(--font-body)', fontSize: 14, fontWeight: 600, cursor: 'pointer' }}>
            {ad.cta}
          </button>
        </div>
      </div>
    </div>
  )
}
