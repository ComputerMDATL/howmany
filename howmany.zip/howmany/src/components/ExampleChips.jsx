/**
 * ExampleChips.jsx
 */
const CHIPS = [
  { emoji: '📄', label: 'sheets in a tree?',   q: 'How many sheets of paper are in a tree?' },
  { emoji: '🏈', label: 'football field?',      q: 'How many feet in a football field?' },
  { emoji: '📞', label: 'phone booth?',         q: 'How many people fit in a phone booth?' },
  { emoji: '🥛', label: 'liters in a gallon?',  q: 'How many liters in a gallon?' },
  { emoji: '🌕', label: 'miles to the Moon?',   q: 'How many miles to the Moon?' },
  { emoji: '✨', label: 'Milky Way stars?',      q: 'How many stars in the Milky Way?' },
]

export function ExampleChips({ onAsk }) {
  return (
    <div style={{ display: 'flex', flexWrap: 'wrap', gap: 7, marginBottom: 18 }}>
      {CHIPS.map(c => (
        <button
          key={c.q}
          onClick={() => onAsk(c.q)}
          style={{
            background: 'rgba(255,255,255,0.06)', border: '1px solid rgba(255,255,255,0.1)',
            borderRadius: 40, padding: '6px 13px', fontSize: 12, color: 'var(--muted)',
            cursor: 'pointer', fontFamily: 'var(--font-body)', whiteSpace: 'nowrap',
          }}
        >
          {c.emoji} {c.label}
        </button>
      ))}
    </div>
  )
}

export default ExampleChips

/**
 * LoadingState.jsx
 */
export function LoadingState({ thought, isRetry }) {
  return (
    <div style={{ textAlign: 'center', padding: '44px 0' }}>
      <div style={{
        width: 44, height: 44,
        border: '3px solid rgba(245,200,66,0.12)',
        borderTopColor: 'var(--gold)',
        borderRadius: '50%',
        animation: 'spin 1s linear infinite',
        margin: '0 auto 14px',
      }} />
      <div style={{ color: 'var(--muted)', fontSize: 13, fontStyle: 'italic' }}>
        {isRetry ? 'Trying again…' : 'Looking that up...'}
      </div>
      <div style={{ color: 'var(--gold)', fontSize: 12, marginTop: 5, minHeight: 17 }}>
        {thought}
      </div>
    </div>
  )
}

/**
 * FallbackCard.jsx
 */
const FB_META = {
  off_topic:    { icon: '🧭', title: "That's not a 'how many' question!" },
  unanswerable: { icon: '🤔', title: 'That one stumped me...' },
  too_vague:    { icon: '🔍', title: 'Can you be more specific?' },
  default:      { icon: '😅', title: "Hmm, couldn't answer that" },
}

export function FallbackCard({ data, onAsk }) {
  const meta = FB_META[data.reason] || FB_META.default
  const esc = (s) => String(s ?? '')

  return (
    <div className="slide-up" style={{
      background: 'var(--card)', border: '1px solid rgba(255,255,255,0.1)',
      borderRadius: 22, overflow: 'hidden',
    }}>
      <div style={{ padding: '22px 22px 18px', display: 'flex', gap: 14, borderBottom: '1px solid rgba(255,255,255,0.06)' }}>
        <div style={{ fontSize: 28, flexShrink: 0 }}>{meta.icon}</div>
        <div>
          <div style={{ fontFamily: 'var(--font-display)', fontSize: 20, fontWeight: 700, color: 'var(--white)', marginBottom: 5 }}>{meta.title}</div>
          <div style={{ fontSize: 13, color: 'var(--muted)', lineHeight: 1.55 }}>{data.message}</div>
        </div>
      </div>
      <div style={{ padding: '18px 22px 22px' }}>
        <div style={{ fontSize: 10, color: 'var(--muted)', fontWeight: 600, letterSpacing: '0.06em', textTransform: 'uppercase', marginBottom: 10 }}>
          {data.reason === 'off_topic' ? 'Things I can answer:' : 'Try one of these:'}
        </div>
        {(data.suggestions || []).map((s, i) => (
          <button key={i} onClick={() => onAsk(s)} style={{
            display: 'flex', alignItems: 'center', gap: 9, width: '100%',
            background: 'var(--card2)', border: '1px solid rgba(245,200,66,0.15)',
            borderRadius: 12, padding: '11px 14px', marginBottom: 8,
            color: 'var(--white)', fontFamily: 'var(--font-body)', fontSize: 13,
            cursor: 'pointer', textAlign: 'left',
          }}>
            <span>💡</span>
            <span style={{ flex: 1 }}>{esc(s)}</span>
            <span style={{ color: 'var(--gold)' }}>→</span>
          </button>
        ))}
      </div>
    </div>
  )
}

/**
 * Toast.jsx
 */
export function Toast({ message }) {
  return (
    <div style={{
      position: 'fixed', bottom: 20, left: '50%',
      transform: `translateX(-50%) translateY(${message ? 0 : 70}px)`,
      background: 'var(--teal)', color: 'var(--sky)',
      padding: '9px 20px', borderRadius: 40, fontSize: 13, fontWeight: 600,
      transition: 'transform 0.3s cubic-bezier(0.22,1,0.36,1)',
      zIndex: 200, pointerEvents: 'none',
    }}>
      {message}
    </div>
  )
}

export default Toast
