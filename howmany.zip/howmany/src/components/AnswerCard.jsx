import { useState, useRef, useEffect } from 'react'
import { drawVisualizer } from '../lib/visualizer'

function safeHtml(s) {
  const d = document.createElement('div')
  d.textContent = String(s ?? '')
  return d.innerHTML
    .replace(/&lt;strong&gt;/g, '<strong>').replace(/&lt;\/strong&gt;/g, '</strong>')
    .replace(/&lt;em&gt;/g, '<em>').replace(/&lt;\/em&gt;/g, '</em>')
}

function esc(s) {
  const d = document.createElement('div')
  d.textContent = String(s ?? '')
  return d.innerHTML
}

export default function AnswerCard({ question, answer, onReset, onShare, interstitial }) {
  const [activeTab, setActiveTab] = useState('steps')
  const canvasRef = useRef(null)
  const [caption, setCaption] = useState('')

  useEffect(() => {
    setActiveTab('steps')
  }, [answer])

  useEffect(() => {
    if (activeTab !== 'visual') return
    document.fonts.ready.then(() => {
      if (canvasRef.current) {
        const cap = drawVisualizer(canvasRef.current, answer)
        setCaption(cap)
      }
    })
  }, [activeTab, answer])

  const tabs = [
    { id: 'steps',  label: '🔢 The math' },
    { id: 'visual', label: '📊 Picture it' },
    { id: 'fact',   label: '💡 Fun fact' },
  ]

  return (
    <div className="slide-up" style={{
      background: 'var(--card)', border: '1px solid rgba(245,200,66,0.12)',
      borderRadius: 22, overflow: 'hidden',
    }}>
      {/* Answer top */}
      <div style={{ padding: '24px 22px 18px', borderBottom: '1px solid rgba(255,255,255,0.06)' }}>
        <div style={{ fontSize: 11, color: 'var(--muted)', letterSpacing: '0.04em', textTransform: 'uppercase', marginBottom: 8 }}>
          {question.replace(/\?$/, '').toUpperCase()}
        </div>
        <div style={{ fontFamily: 'var(--font-display)', fontSize: 48, fontWeight: 900, color: 'var(--gold)', lineHeight: 1, marginBottom: 6 }}>
          {answer.answer}
        </div>
        <div style={{ fontSize: 14, color: 'var(--white)', opacity: 0.8, lineHeight: 1.5 }}>
          {answer.unit ? `${answer.unit} — ` : ''}{answer.subtitle}
        </div>
        {answer.type === 'research' && answer.range && (
          <div style={{
            display: 'inline-flex', alignItems: 'center', gap: 5, marginTop: 8,
            background: 'rgba(0,201,167,0.1)', border: '1px solid rgba(0,201,167,0.22)',
            borderRadius: 40, padding: '4px 11px', fontSize: 11, color: 'var(--teal)',
          }}>
            ~ Est. range: {answer.range.low}–{answer.range.high} {answer.range.unit || ''}
          </div>
        )}
      </div>

      {/* Tabs */}
      <div style={{ display: 'flex', borderBottom: '1px solid rgba(255,255,255,0.06)' }}>
        {tabs.map(t => (
          <button key={t.id} onClick={() => setActiveTab(t.id)} style={{
            flex: 1, padding: '11px 6px', textAlign: 'center',
            fontSize: 12, fontFamily: 'var(--font-body)', fontWeight: 500,
            color: activeTab === t.id ? 'var(--gold)' : 'var(--muted)',
            borderBottom: `2px solid ${activeTab === t.id ? 'var(--gold)' : 'transparent'}`,
            background: 'none', border: 'none',
            borderBottom: `2px solid ${activeTab === t.id ? 'var(--gold)' : 'transparent'}`,
            cursor: 'pointer', transition: 'all 0.18s',
          }}>
            {t.label}
          </button>
        ))}
      </div>

      {/* Tab panels */}
      <div style={{ padding: '20px 22px' }}>
        {activeTab === 'steps' && (
          <div>
            {(answer.steps || []).map(s => (
              <div key={s.n} style={{ display: 'flex', gap: 12, marginBottom: 16, alignItems: 'flex-start' }}>
                <div style={{
                  width: 26, height: 26, borderRadius: '50%',
                  background: 'rgba(245,200,66,0.1)', border: '1px solid rgba(245,200,66,0.22)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: 11, fontWeight: 600, color: 'var(--gold)', flexShrink: 0,
                }}>
                  {s.n}
                </div>
                <div
                  style={{ fontSize: 13, color: 'rgba(248,244,236,0.78)', lineHeight: 1.6 }}
                  dangerouslySetInnerHTML={{ __html: safeHtml(s.text) }}
                />
              </div>
            ))}
          </div>
        )}

        {activeTab === 'visual' && (
          <div>
            <canvas ref={canvasRef} height={160} style={{ width: '100%', height: 'auto', display: 'block', borderRadius: 8 }} />
            {caption && <div style={{ fontSize: 11, color: 'var(--muted)', marginTop: 10, lineHeight: 1.5 }}>{caption}</div>}
          </div>
        )}

        {activeTab === 'fact' && (
          <div>
            <div style={{
              background: 'rgba(0,201,167,0.06)', border: '1px solid rgba(0,201,167,0.18)',
              borderRadius: 12, padding: '14px 16px',
            }}>
              <div style={{ fontSize: 10, color: 'var(--teal)', fontWeight: 600, letterSpacing: '0.06em', textTransform: 'uppercase', marginBottom: 5 }}>
                Did you know?
              </div>
              <div style={{ fontSize: 13, color: 'rgba(248,244,236,0.82)', lineHeight: 1.6 }}>
                {answer.funFact}
              </div>
            </div>

            {(answer.sources || []).length > 0 && (
              <div style={{ marginTop: 14, paddingTop: 12, borderTop: '1px solid rgba(255,255,255,0.06)' }}>
                <div style={{ fontSize: 10, color: 'var(--muted)', fontWeight: 600, letterSpacing: '0.05em', textTransform: 'uppercase', marginBottom: 7 }}>Sources</div>
                {answer.sources.map((s, i) => (
                  <div key={i} style={{ fontSize: 11, color: 'var(--muted)', marginBottom: 3, display: 'flex', gap: 5, alignItems: 'flex-start' }}>
                    <div style={{ width: 3, height: 3, borderRadius: '50%', background: 'var(--muted)', marginTop: 5, flexShrink: 0 }} />
                    {s}
                  </div>
                ))}
              </div>
            )}

            {/* AD SLOT 3: Native ad in Fun Fact tab — replace with real AdSense slot */}
            <div style={{
              marginTop: 14, background: 'rgba(245,200,66,0.04)',
              border: '1px solid rgba(245,200,66,0.12)', borderRadius: 12,
              padding: '14px 16px', display: 'flex', gap: 12,
            }}>
              <span style={{ fontSize: 9, color: 'var(--muted)', fontWeight: 600, letterSpacing: '0.06em', textTransform: 'uppercase', background: 'rgba(255,255,255,0.06)', padding: '2px 6px', borderRadius: 4, flexShrink: 0, alignSelf: 'flex-start' }}>Ad</span>
              <div>
                <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--white)', marginBottom: 3 }}>🌍 National Geographic Kids</div>
                <div style={{ fontSize: 11, color: 'var(--muted)', lineHeight: 1.5 }}>Dive deeper into the science behind your question. Wild facts, videos & experiments.</div>
                <a href="https://kids.nationalgeographic.com" target="_blank" rel="noopener noreferrer" style={{ fontSize: 11, color: 'var(--gold)', marginTop: 5, display: 'block' }}>Explore natgeokids.com →</a>
              </div>
            </div>
          </div>
        )}
      </div>

      {/* Action bar */}
      <div style={{ padding: '14px 22px', borderTop: '1px solid rgba(255,255,255,0.06)', display: 'flex', alignItems: 'center', gap: 9 }}>
        <button onClick={onShare} style={{
          flex: 1, background: 'var(--gold)', color: 'var(--sky)', border: 'none',
          borderRadius: 40, padding: '11px 18px', fontFamily: 'var(--font-body)',
          fontSize: 13, fontWeight: 600, cursor: 'pointer', display: 'flex',
          alignItems: 'center', justifyContent: 'center', gap: 6,
        }}>
          🎴 Share this answer
        </button>
        <button onClick={onReset} style={{
          background: 'transparent', border: '1px solid rgba(255,255,255,0.13)',
          color: 'var(--muted)', borderRadius: 40, padding: '11px 16px',
          fontFamily: 'var(--font-body)', fontSize: 12, cursor: 'pointer',
          whiteSpace: 'nowrap',
        }}>
          Ask another
          {interstitial.showingCounter && (
            <span style={{ fontSize: 10, opacity: 0.5, marginLeft: 4 }}>
              · ad in {interstitial.untilNext}
            </span>
          )}
        </button>
      </div>
    </div>
  )
}
