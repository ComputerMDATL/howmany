export default function Header() {
  return (
    <div style={{ textAlign: 'center', padding: '28px 0 22px' }}>
      <div style={{ fontFamily: 'var(--font-display)', fontSize: 40, fontWeight: 900, color: 'var(--gold)', letterSpacing: -1, lineHeight: 1 }}>
        How <span style={{ color: 'var(--white)', fontWeight: 400, fontStyle: 'italic' }}>many</span>?
      </div>
      <div style={{ fontSize: 13, color: 'var(--muted)', marginTop: 6 }}>
        Ask anything. Get a real answer with the math shown.
      </div>
      <div style={{ marginTop: 8 }}>
        <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5, background: 'rgba(0,201,167,0.1)', border: '1px solid rgba(0,201,167,0.2)', borderRadius: 20, padding: '2px 10px', fontSize: 10, color: 'var(--teal)', fontWeight: 600 }}>
          ✓ v6 — production ready
        </span>
      </div>
    </div>
  )
}
