# How Many? 🌟

> Ask anything. Get a real answer with the math shown.

A kid-friendly, voice-enabled conversion and curiosity app.
Built with React + Vite (frontend) and Express + Anthropic SDK (backend).

---

## Project structure

```
howmany/
├── src/                      ← React frontend (deploys to Vercel)
│   ├── components/
│   │   ├── Stars.jsx         Background star animation
│   │   ├── Header.jsx        Logo + tagline
│   │   ├── QuestionInput.jsx Text input + mic button
│   │   ├── ExampleChips.jsx  Chips, LoadingState, FallbackCard, Toast
│   │   ├── AnswerCard.jsx    Answer + tabs (math / visualizer / fact)
│   │   ├── AdBanner.jsx      Ad slot 1 (banner) + Interstitial (slot 2)
│   │   └── SharePanel.jsx    Share card builder + download
│   ├── hooks/
│   │   ├── useAsk.js         All API call logic, abort, retry
│   │   └── useInterstitial.js Ad counter, countdown, skip
│   ├── lib/
│   │   ├── visualizer.js     5 Canvas visualizer templates
│   │   └── shareCard.js      1200×630 OG share card renderer
│   ├── App.jsx               Top-level layout + state
│   ├── main.jsx              React entry point
│   └── index.css             CSS variables, resets, animations
├── server/
│   ├── index.js              Express API — proxies Anthropic, tool-use loop
│   ├── package.json
│   └── .env.example          Copy to .env and fill in your keys
├── index.html                HTML shell + font imports + AdSense comment
├── vite.config.js            Dev proxy → backend
├── vercel.json               Routes /api/* to your Render backend
├── render.yaml               One-click Render deploy config
└── .gitignore
```

---

## Step 1 — Local setup (do this first)

### Frontend

```bash
# From the howmany/ root
npm install
npm run dev
# → Opens at http://localhost:5173
```

### Backend

```bash
cd server
npm install

# Create your .env file
cp .env.example .env
# Open .env and paste your Anthropic API key

npm run dev
# → Runs at http://localhost:3001
```

The Vite dev server automatically proxies `/api` calls to port 3001,
so the frontend and backend work together out of the box.

---

## Step 2 — Push to GitHub

```bash
# From howmany/ root
git init
git add .
git commit -m "Initial commit — How Many? v1"

# Create a new repo on github.com, then:
git remote add origin https://github.com/YOUR_USERNAME/howmany.git
git branch -M main
git push -u origin main
```

---

## Step 3 — Deploy the backend to Render

1. Go to **render.com** → New → Web Service
2. Connect your GitHub repo
3. Set **Root Directory** to `server`
4. Set **Build Command** to `npm install`
5. Set **Start Command** to `npm start`
6. Add these **Environment Variables** in the Render dashboard:
   - `ANTHROPIC_API_KEY` → your key from console.anthropic.com
   - `FRONTEND_URL` → your Vercel URL (fill in after step 4)
7. Click **Deploy**
8. Copy your Render URL — it looks like `https://howmany-server.onrender.com`

---

## Step 4 — Deploy the frontend to Vercel

1. Open `vercel.json` and replace the destination URL with your Render URL:
   ```json
   "destination": "https://YOUR-RENDER-URL.onrender.com/api/:path*"
   ```
2. Commit and push that change to GitHub
3. Go to **vercel.com** → New Project → Import your GitHub repo
4. Leave all settings as default (Vercel auto-detects Vite)
5. Click **Deploy**
6. Copy your Vercel URL (e.g. `https://howmany.vercel.app`)

---

## Step 5 — Wire them together

1. Go back to your Render dashboard
2. Set `FRONTEND_URL` to your Vercel URL
3. Redeploy the Render service (or it picks up env changes automatically)

Your app is now live. ✅

---

## Step 6 — Set up ads (when ready)

### Google AdSense (web)

1. Apply at **adsense.google.com** — approval takes 1–7 days
2. Once approved, get your publisher ID (format: `ca-pub-XXXXXXXXXXXXXXXX`)
3. In `index.html`, uncomment the AdSense script tag and add your publisher ID
4. In `src/components/AdBanner.jsx`, replace the mock `<div>` with a real `<ins>` tag:

```jsx
// Replace the mock ad div with:
<ins className="adsbygoogle"
  style={{ display: 'block' }}
  data-ad-client="ca-pub-XXXXXXXXXXXXXXXX"
  data-ad-slot="XXXXXXXXXX"
  data-ad-format="auto"
  data-full-width-responsive="true"
  data-tag-for-child-directed-treatment="1"   // ← REQUIRED — kid-safe / COPPA
/>
```

Then add this in a `useEffect`:
```js
useEffect(() => {
  (window.adsbygoogle = window.adsbygoogle || []).push({})
}, [])
```

5. Repeat for the native ad slot in `src/components/AnswerCard.jsx` (Fun Fact tab)

### Blocking inappropriate categories (do this before going live)
In your AdSense dashboard → Brand safety → Content → Block categories:
- Dating & personals
- Alcohol
- Gambling
- Political
- Violence & weapons
- Weight loss

---

## Ad slots reference

| Slot | Location | Component | Format |
|------|----------|-----------|--------|
| 1 | Below answer card | `AdBanner.jsx` | Banner 320×50 / 728×90 |
| 2 | Every 3rd "Ask another" | `AdBanner.jsx` (Interstitial) | Fullscreen |
| 3 | Fun Fact tab bottom | `AnswerCard.jsx` | Native / in-feed |

---

## Environment variables reference

| Variable | Where | Description |
|----------|-------|-------------|
| `ANTHROPIC_API_KEY` | Render | Your Anthropic key — never put this in the frontend |
| `FRONTEND_URL` | Render | Your Vercel URL — used for CORS |
| `PORT` | Render | Set automatically by Render |

---

## Common issues

**"API call fails in production but works locally"**
→ Check that `vercel.json` destination URL matches your exact Render URL.
→ Check that `FRONTEND_URL` in Render matches your exact Vercel URL (no trailing slash).

**"Ads not showing"**
→ AdSense takes 1–7 days to approve new sites. The mock ads will show until then.
→ Make sure you uncommented the AdSense script in `index.html`.

**"Voice input doesn't work"**
→ Voice requires Chrome or Edge. Safari on iOS uses a different API — works on mobile Safari too, but needs the `webkitSpeechRecognition` path which is already handled.

**"Render goes to sleep"**
→ Free Render plans sleep after 15 minutes of inactivity (cold start ~30s).
→ Upgrade to a paid Render plan ($7/mo) to keep it always-on before launch.

---

## Tech stack

| Layer | Tech | Deployed to |
|-------|------|-------------|
| Frontend | React 18 + Vite | Vercel (free) |
| Backend | Node.js + Express | Render (free tier) |
| AI | Anthropic Claude + web_search | via backend |
| Fonts | Fraunces + DM Sans | Google Fonts CDN |
| Ads | Google AdSense (web) | via index.html script |
| Share cards | HTML5 Canvas | client-side |
| Voice | Web Speech API | browser-native |
