/**
 * server/index.js
 * Express backend for How Many?
 *
 * Responsibilities:
 *  - Keeps the ANTHROPIC_API_KEY off the browser
 *  - Runs the multi-turn tool-use loop
 *  - Returns clean JSON (or fallback JSON) to the frontend
 *  - Rate-limits to 60 requests/IP/minute to control costs
 */
import express from 'express'
import cors from 'cors'
import rateLimit from 'express-rate-limit'
import Anthropic from '@anthropic-ai/sdk'
import 'dotenv/config'

const app  = express()
const PORT = process.env.PORT || 3001
const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY })

app.use(cors({ origin: process.env.FRONTEND_URL || 'http://localhost:5173' }))
app.use(express.json())

// Rate limit: 60 requests per IP per minute
const limiter = rateLimit({
  windowMs: 60 * 1000,
  max: 60,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'http_429' },
})
app.use('/api', limiter)

// Health check for Render
app.get('/health', (_, res) => res.json({ ok: true }))

// ── System prompt ────────────────────────────────────────────────────────────
const SYSTEM = `You are "How Many?" — a curious, kid-friendly app answering questions like "How many sheets of paper in a tree?" or "How many feet in a football field?"

Classify every question as:
• "conversion" — pure unit math
• "research"   — needs real-world data
• "fallback"   — unanswerable with a number, or off-topic

For fallback: {"type":"fallback","reason":"unanswerable"|"off_topic"|"too_vague","message":string,"suggestions":[string,string,string]}

For conversion/research — raw JSON, no markdown:
{"answer":string,"unit":string,"subtitle":string,"type":"conversion"|"research","range":{"low":string,"high":string,"unit":string}|null,"visualType":"stack"|"ruler"|"people"|"journey"|"starfield","steps":[{"n":number,"text":string}],"comparisons":[{"label":string,"value":number,"color":string}],"funFact":string,"sources":string[]}

visualType: stack=counts of objects, ruler=human-scale distances, people=capacity, journey=large distances, starfield=billions+
Numbers: comma-format integers (8,333). comparisons.value = plain number only. Decimals: max 3 places.
Colors: "#F5C842","#00C9A7","#FF6B6B","#A78BFA" only.
Steps: <strong> for key numbers only. Show arithmetic. Kid-friendly, enthusiastic tone.

--- EXAMPLES ---
Q:"How many liters in a gallon?"
{"answer":"3.785","unit":"liters","subtitle":"One US gallon holds exactly 3.785 liters","type":"conversion","range":null,"visualType":"stack","steps":[{"n":1,"text":"1 US gallon = <strong>231 cubic inches</strong>"},{"n":2,"text":"231 ÷ 61.024 = <strong>3.785 liters</strong>"},{"n":3,"text":"A 2-liter bottle is about <strong>half a gallon</strong>"}],"comparisons":[{"label":"1 gallon","value":3785,"color":"#F5C842"},{"label":"2-liter bottle","value":2000,"color":"#00C9A7"},{"label":"1 liter","value":1000,"color":"#FF6B6B"}],"funFact":"The UK gallon is 20% bigger than the US gallon!","sources":["US NIST","BIPM"]}

Q:"How many people fit in a phone booth?"
{"answer":"4","unit":"adults comfortably","subtitle":"A standard BT phone box comfortably fits 4 adults","type":"research","range":{"low":"4","high":"14","unit":"people"},"visualType":"people","steps":[{"n":1,"text":"BT box floor: <strong>36×36 inches</strong> = 0.84 m²"},{"n":2,"text":"One adult needs <strong>~0.21 m²</strong>"},{"n":3,"text":"0.84 ÷ 0.21 = <strong>4 people</strong>"},{"n":4,"text":"World record: <strong>14</strong>, South Africa 2012"}],"comparisons":[{"label":"Comfortable","value":4,"color":"#00C9A7"},{"label":"Cozy","value":8,"color":"#F5C842"},{"label":"World record","value":14,"color":"#FF6B6B"}],"funFact":"Phone-booth stuffing was a 1950s college craze!","sources":["Guinness World Records","BT Heritage"]}

Q:"What is the capital of France?"
{"type":"fallback","reason":"off_topic","message":"I only answer 'How many' questions!","suggestions":["How many people live in Paris?","How many km wide is France?","How many countries are in Europe?"]}
--- END EXAMPLES ---`

// ── Multi-turn tool-use loop ──────────────────────────────────────────────────
async function askWithTools(question) {
  const MAX_TURNS = 6
  const messages = [{ role: 'user', content: question }]

  for (let turn = 0; turn < MAX_TURNS; turn++) {
    const response = await client.messages.create({
      model:      'claude-sonnet-4-20250514',
      max_tokens: 1500,
      system:     SYSTEM,
      tools:      [{ type: 'web_search_20250305', name: 'web_search' }],
      messages,
    })

    if (response.stop_reason === 'max_tokens') throw new Error('truncated')

    const textBlocks = response.content.filter(b => b.type === 'text')
    if (response.stop_reason === 'end_turn' && textBlocks.length) {
      return textBlocks.map(b => b.text).join('')
    }

    // Model used a tool — feed results back and loop
    messages.push({ role: 'assistant', content: response.content })
    const toolResults = response.content
      .filter(b => b.type === 'tool_use')
      .map(b => ({ type: 'tool_result', tool_use_id: b.id, content: '' }))

    if (!toolResults.length) break
    messages.push({ role: 'user', content: toolResults })
  }

  throw new Error('tool_loop_exceeded')
}

// ── POST /api/ask ─────────────────────────────────────────────────────────────
app.post('/api/ask', async (req, res) => {
  const { question } = req.body
  if (!question || typeof question !== 'string' || question.trim().length < 3) {
    return res.status(400).json({ error: 'invalid_question' })
  }

  try {
    const raw = await askWithTools(question.trim().slice(0, 300))
    const cleaned = raw.replace(/```json|```/g, '').trim()
    const parsed = JSON.parse(cleaned)
    res.json(parsed)
  } catch (err) {
    console.error('[/api/ask]', err.message)

    // Return a graceful fallback rather than a 500
    const message =
      err.message === 'truncated'       ? "Try a more specific question!" :
      err.message === 'tool_loop_exceeded' ? "Something went wrong. Try rephrasing." :
      err.message?.startsWith('parse')  ? "Got a confusing answer — try rephrasing." :
      "Something went wrong. Try again in a moment."

    res.json({
      type:        'fallback',
      reason:      'unanswerable',
      message,
      suggestions: ['How many feet in a mile?', 'How many gallons in a bathtub?', 'How many bones are in the human body?'],
    })
  }
})

app.listen(PORT, () => console.log(`How Many? server running on :${PORT}`))
